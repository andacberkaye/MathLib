importantNumbers = {
    "pi" : 3.141592653589793,
    "terms": 50,
    "h": 1e-5
}

def add(*args: float) -> float:
    """
    Adds the entered numbers in order.

    Parameters:
        *args (int | float):
            Any number of integer or float values.

    Return value:
        int | float:
            The sum of all entered numbers.
    """

    addition = 0

    for i in args:
        addition += i
    
    return addition

def sub(*args: float) -> float:
    """
        Subtracts the entered numbers in order.

        Parameters:
            - At least one number is required

            *args (int | float):
                Any number of integer or float values.

        Return value:
            int | float:
                The subtracting all entered numbers.
    """

    if len(args) == 0:
        raise ValueError("At least one number is required")
    subtract = args[0]

    for i in args[1:]:
        subtract -= i
    
    return subtract

def division(p: float, b: float) -> float:
    """
        Divides two numbers.

        Parameters:
            p (int | float):
                Dividend number

            b (int | float):
                Divisor number

        Returns:
            int | float:
                Division result
    """
        
    if b == 0:
        raise ZeroDivisionError("A divisor cannot be zero")
    return p / b
    
def multi(*args: float) -> float:
    """
        Multiplication the entered numbers in order.

        Parameters:
            *args (int | float):
                Any number of integer or float values.

        Return value:
            int | float:
                The multiplication of all entered numbers.
    """

    if len(args) == 0:
        raise ValueError("At least one number is required")
    
    multiplication = args[0]

    for i in args[1:]:
        multiplication *= i
    
    return multiplication

def mod(a: float, n: float) -> float:
    """
        Calculates the modulus of the first number relative to the second.

        Parameters:
            a (int | float):
                The number for which the modulus is calculated

            n (int | float):
                The divisor

        Return value:
            int | float:
                The result of the modulus operation
    """
    
    if n == 0:
        raise ZeroDivisionError("A divisor cannot be zero")
    return a % n

def power(b: float,x: float) -> float:
    """
    Calculates the power of the first number raised to the second number

        Parameters:
            b (int | float):
                The number to be raised to a power

            x (int | float):
                The exponent

        Return value:
            int | float:
                The result of raising the first number to the second number
    """

    return b**x

def absolute(x: float) -> float:
    """
        Calculates the absolute value of the entered number

        Parameters:
            x (int | float):
                The number whose absolute value is calculated

        Return value:
            int | float:
                The number whose absolute value is calculated
    """

    if x < 0:
        return -x
    else:
        return x
    
def minimum(*args: float) -> float:
    """
        Finds the smallest of the entered numbers

        Parameters:
            args (int | float):
                The numbers entered, from which the smallest is to be found

        Return value:
            int | float:
                The smallest number found
    """
    if len(args) == 0:
        raise ValueError("At least one number is required")
    min_number = args[0]

    for i in args[1:]:
        if i < min_number:
            min_number = i
        else:
            continue
    return min_number

def maximum(*args: float) -> float:
    """
        Finds the biggest of the entered numbers

        Parameters:
            args (int | float):
                The numbers entered, from which the biggest is to be found

        Return value:
            int | float:
                The biggest number found
    """
    if len(args) == 0:
        raise ValueError("At least one number is required") 
    max_number = args[0]

    for i in args[1:]:
        if i > max_number:
            max_number = i
        else:
            continue
    return max_number

def avg(*args: float) -> float:
    """
        Calculates the average of the entered numbers

        Parameters:
            args (int | float):
                Calculates the average of the entered numbers

        Return value:
            int | float:
                The calculated average
    """
    if len(args) == 0:
        raise ValueError("At least one number is required")

    addition = 0

    for i in args:
        addition += i

    return addition / len(args)

def factorial(n: int) -> int:
    """
        Calculates the factorial of the entered number

        Parameters:
            n (int | float):
                Calculates the factorial of the entered number

        Return value:
            int | float:
                The number obtained as the factorial
    """
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers")
    fac = 1
    while n > 0:
        fac = fac*n
        n -= 1
    return fac

def parity(x: int) -> str:
    """
        Determines whether the entered number is even or odd

        Parameters:
            x (int | float):
                The number whose parity is to be determined

        Return value:
            int | float:
                The result of the parity calculation
    """

    if x % 2 == 0:
        return "Even"
    else:
        return "Odd"
    
def is_prime(x: int) -> bool:

    """
        Determines whether the entered number is prime

        Parameters:
            x (int | float):
                The number to be checked for primality

        Return value:
            int | float:
                The result of the primality check
    """

    if x <= 1:
        return False

    for i in range(2, int(x**0.5) + 1):
        if x % i == 0:
            return False

    return True

def gcd(a: int, b: int) -> int:
    """
        Returns the greatest common divisor (GCD) of two integers.

        Parameters:
            a (int):
                First integer.

            b (int):
                Second integer.

        Return value:
            int:
                Greatest common divisor of the given integers.
    """

    while b != 0:
        a, b = b, a % b

    return absolute(a)

def lcm(a: int, b: int) -> int:
    """
    Returns the least common multiple (LCM) of two integers.

    Parameters:
        a (int):
            First integer.

        b (int):
            Second integer.

    Return value:
        int:
            Least common multiple of the given integers.
    """

    return absolute(a * b) // gcd(a, b)

def prime_factors(a: int) -> list[int]:
    """
        Returns the prime factors of a given integer.

        Parameters:
            number (int):
                Integer to factorize.

        Return value:
            list:
                List containing prime factors.
    """

    if a <= 1:
        raise ValueError("Number must be greater than 1")
    factors=[]
    divisor = 2

    while a > 1:
        while a % divisor == 0:
            factors.append(divisor)
            a //= divisor
        divisor += 1

    return factors

def fibonacci(n: int, mode: str) -> int | list[int]:
    """
    Fibonacci number or series generator.

    Parameters:
        n (int):
            Number of elements (for series) or position (for number mode)

        mode (str):
            "series" -> returns fibonacci series
            "number" -> returns nth fibonacci number

    Return value:
        int | list[int]:
            Fibonacci number or fibonacci sequence
    """

    if n < 0:
        raise ValueError("n must be >= 0")

    a, b = 0, 1

    if mode == "number":
        for _ in range(n):
            a, b = b, a + b
        return a

    elif mode == "series":
        series = []

        for _ in range(n):
            series.append(a)
            a, b = b, a + b

        return series

    else:
        raise ValueError("mode must be 'series' or 'number'")
    
def add_range(start: float, end: float, amount: float = 1) -> float:
    """
    Calculates the sum of numbers in a given range with a step value.

    The function starts from 'start' and adds numbers up to 'end'
    by increasing each step with 'amount'. If 'amount' is not provided,
    it defaults to 1.

    Parameters:
        start (float):
            The starting value of the range.

        end (float):
            The ending value of the range (inclusive).

        amount (float, optional):
            The step size between numbers. Default is 1.
            Must not be 0.

    Returns:
        float:
            The sum of all numbers in the range.

    Raises:
        ValueError:
            If amount is 0.
    """

    if amount == 0:
        raise ValueError("amount cannot be 0")

    total = 0
    current = start

    while current <= end:
        total += current
        current += amount

    return total

def sqrt(a: float) -> float:
    """
    Calculates the square root of a number.

    The function returns the value which, when multiplied by itself,
    gives the original number (a).

    Parameters:
        a (float):
            The number to calculate the square root of.
            Must be >= 0 for real results.

    Returns:
        float:
            The square root of the given number.

    Raises:
        ValueError:
            If a is negative (since real square root is undefined).
    """

    if a < 0:
        raise ValueError("Square root of negative number is not real")
    return a ** 0.5

def cube_root(x: float) -> float:
    """
    Calculates the cube root of a number.

    The function returns the value which, when multiplied by itself
    three times, gives the original number.

    Parameters:
        x (float):
            The number whose cube root is to be calculated.

    Returns:
        float:
            The cube root of the given number.
    """

    return absolute(x) ** (1 / 3)

def nth_root(x: float, n: int) -> float:
    """
    Calculates the nth root of a number.

    The function returns the value which, when raised to the power
    of n, gives the original number.

    Parameters:
        x (float):
            The number whose root is to be calculated.

        n (int):
            The degree of the root.

    Returns:
        float:
            The nth root of the given number.

    Raises:
        ValueError:
            If n is 0.
            If x is negative and n is even.
    """

    if n == 0:
        raise ValueError("n cannot be 0")

    if x < 0 and n % 2 == 0:
        raise ValueError("Even root of a negative number is not real")

    if x >= 0:
        return x ** (1 / n)
    else:
        return -((-x) ** (1 / n))
    
def percentage(value: float, percent: float) -> float:
    """
    Calculates a percentage of a given value.

    Parameters:
        value (float):
            The original value.

        percent (float):
            The percentage to calculate.

    Returns:
        float:
            The calculated percentage of the value.
    """

    return value * percent / 100

def round_number(x: float) -> int:
    """
    Rounds a number to the nearest integer.

    Parameters:
        x (float):
            The number to be rounded.

    Returns:
        int:
            The nearest integer to the given number.
    """
    if x >= 0:
        return int(x + 0.5)
    else:
        return int(x - 0.5)

def ceil_number(x: float) -> int:
    """
    Returns the smallest integer greater than or equal to x.

    Parameters:
        x (float):
            The number to be rounded up.

    Returns:
        int:
            The smallest integer greater than or equal to x.
    """
    if x == int(x):
        return int(x)
    return int(x) + (1 if x > 0 else 0)

def floor_number(x: float) -> int:
    """
    Returns the greatest integer less than or equal to x.

    Parameters:
        x (float):
            The number to be rounded down.

    Returns:
        int:
            The greatest integer less than or equal to x.
    """
    if x == int(x):
        return int(x)
    return int(x) - (1 if x < 0 else 0)

def sin(x: float) -> float:
    """
    Calculates sine using Taylor series approximation.

    Parameters:
        x (float):
            Angle in radians.

    Returns:
        float:
            Approximate sine value.
    """
    result = 0.0
    term = x

    for i in range(10):
        result += term
        term *= -x * x / ((2 * i + 2) * (2 * i + 3))

    return result

def cos(x: float) -> float:
    """
    Calculates cosine using Taylor series approximation.

    Parameters:
        x (float):
            Angle in radians.

    Returns:
        float:
            Approximate cosine value.
    """
    result = 1.0
    term = 1.0

    for i in range(1, 10):
        term *= -x * x / ((2 * i - 1) * (2 * i))
        result += term

    return result

def tan(x: float) -> float:
    """
    Calculates tangent as sin(x) / cos(x).

    Parameters:
        x (float):
            Angle in radians.

    Returns:
        float:
            Approximate tangent value.
    """
    c = cos(x)
    if abs(c) < 1e-12:
        raise ValueError("tan undefined (cos(x) too close to 0)")
    return sin(x) / c

def cot(x: float) -> float:
    """
    Calculates cotangent as cos(x) / sin(x).

    Parameters:
        x (float):
            Angle in radians.

    Returns:
        float:
            Approximate cotangent value.
    """
    s = sin(x)
    if abs(s) < 1e-12:
        raise ValueError("cot undefined (sin(x) too close to 0)")
    return cos(x) / s

def hypotenuse(a: float, b: float) -> float:
    """
    Calculates hypotenuse using Newton's method (no math.sqrt).

    Parameters:
        a (float):
            First side.

        b (float):
            Second side.

    Returns:
        float:
            Hypotenuse value.
    """
    value = a * a + b * b

    result = value
    for _ in range(10):
        result = (result + value / result) / 2

    return result

def clamp(x: int | float, min_val: int | float, max_val: int | float) -> int | float:
    """
        Restricts a value to a specified range.

        Parameters:
            x (int | float):
                Value to clamp.

            min_val (int | float):
                Minimum allowed value.

            max_val (int | float):
                Maximum allowed value.

        Returns:
            int | float:
                Clamped value.
    """

    if min_val > max_val:
        raise ValueError("min_val cannot be greater than max_val")

    return maximum(min_val, minimum(x, max_val))

def distance_2d(
    x1: int | float,
    y1: int | float,
    x2: int | float,
    y2: int | float
) -> float:
    """
        Calculates the Euclidean distance between two points in 2D space.

        Parameters:
            x1 (int | float):
                X coordinate of the first point.

            y1 (int | float):
                Y coordinate of the first point.

            x2 (int | float):
                X coordinate of the second point.

            y2 (int | float):
                Y coordinate of the second point.

        Returns:
            float:
                Distance between the two points.
    """

    return sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

def degrees_to_radians(x: int | float) -> float:
    """
        Converts degrees to radians.

        Parameters:
            x (int | float):
                Angle in degrees.

        Returns:
            float:
                Angle in radians.
    """
    return x * importantNumbers["pi"] / 180

def radians_to_degrees(x: int | float) -> float:
    """
        Converts radians to degrees.

        Parameters:
            x (int | float):
                Angle in radians.

        Returns:
            float:
                Angle in degrees.
    """
    return x * 180 / importantNumbers["pi"]

def ln(x: float) -> float:
    """
        Computes the natural logarithm of a number using a Taylor series approximation.

        Parameters:
            x (float):
                A positive real number.

        Returns:
            float:
                Natural logarithm of x (ln(x)).

        Notes:
            - x must be greater than 0.
            - The function uses a series approximation, so accuracy depends on the number of iterations (terms).
            - Results are approximate, not exact.
    """
    if x <= 0:
        raise ValueError("x must be > 0")

    k = 0
    while x > 2:
        x /= 2
        k += 1
    while x < 0.5:
        x *= 2
        k -= 1

    n = (x - 1) / (x + 1)
    result = 0

    for i in range(1, 2 * importantNumbers["terms"], 2):
        result += (1 / i) * (n ** i)

    return 2 * result + k


def log(x: float, base: float) -> float:
    """
        Computes logarithm of a number with a given base.

        Parameters:
            x (float):
                A positive real number.

            base (float):
                Logarithm base (must be positive and not equal to 1).

        Returns:
            float:
                Logarithm of x in the specified base.

        Notes:
            - This function uses the natural logarithm (ln) for computation:
              log(x, base) = ln(x) / ln(base)
            - Both x and base must be valid for logarithmic operations.
    """
    if base <= 0 or base == 1:
        raise ValueError("Invalid base")

    return ln(x) / ln(base)

def exp(x: int | float) -> float:
    """
        Computes the exponential function e^x using a Taylor series approximation.

        Parameters:
            x (int | float):
                Input value.

        Returns:
            float:
                Approximated value of e^x.

        Notes:
            - Uses Taylor series expansion:
              e^x = sum(x^n / n!)
            - Accuracy depends on the number of terms defined in importantNumbers["terms"].
    """
    result = 0

    for n in range(importantNumbers["terms"]):
        result += (x ** n) / factorial(n)

    return result

def sigmoid(x: int | float) -> float:
    """
        Computes the sigmoid activation function.

        Parameters:
            x (int | float):
                Input value.

        Returns:
            float:
                Value between 0 and 1.

        Notes:
            - Defined as:
              sigmoid(x) = 1 / (1 + e^(-x))
            - Commonly used in machine learning and logistic regression.
    """
    return 1 / (1 + exp(-x))

def derivative(f, x):
    """
        Approximates the derivative of a function at a given point using central difference method.

        Parameters:
            f (function):
                Function to differentiate.

            x (int | float):
                Point at which derivative is calculated.

        Returns:
            float:
                Approximate derivative at point x.

        Notes:
            - Uses central difference formula:
              (f(x+h) - f(x-h)) / (2h)
            - Accuracy depends on step size h.    
    """

    return (f(x + importantNumbers["h"]) - f(x - importantNumbers["h"])) / (2 * importantNumbers["h"])

def integral(f, a, b):
    """
        Approximates the definite integral of a function using the trapezoidal rule.

        Parameters:
            f (function):
                Function to integrate.

            a (float):
                Start of interval.

            b (float):
                End of interval.

        Returns:
            float:
                Approximate integral value over [a, b].

        Notes:
            - Uses trapezoidal approximation:
              area ≈ sum of trapezoids under curve
            - Accuracy increases with higher n.
    """

    n = 1000
    step = (b - a) / n
    total = 0

    for i in range(n):
        x1 = a + i * step
        x2 = x1 + step
        total += (f(x1) + f(x2)) / 2 * step

    return total